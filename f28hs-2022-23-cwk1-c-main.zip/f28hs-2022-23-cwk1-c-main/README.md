# F28HS Coursework 1

This is the template project for F28HS Coursework 1: Image Steganography
in C. For details of the coursework, see the coursework specification on
Canvas.
